# file: run_email_search.py

from src.PyFiles.GoogleKse import search_emails_and_display
from src.PyFiles.app import app

if __name__ == "__main__":
    with app.app_context():
        print("Starter langvarig jobb (WebJob)...")
        success = search_emails_and_display(batch_size=5)
        if success:
            print("Jobb ferdig uten feil.")
        else:
            print("Jobb avsluttet med feil.")
